package model.cards.spells;

import model.cards.minions.Minion;

public interface LeechingSpell {
	public int performAction(Minion m);
}
